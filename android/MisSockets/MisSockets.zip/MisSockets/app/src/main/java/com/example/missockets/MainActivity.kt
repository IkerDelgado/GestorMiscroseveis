package com.example.missockets

import android.app.AlertDialog
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.example.missockets.R
import com.example.missockets.network.RetrofitClient
import com.example.missockets.network.Script
import com.example.missockets.network.ScriptStatus
import com.example.missockets.network.SocketManager
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import io.socket.emitter.Emitter
import org.json.JSONArray
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : ComponentActivity() {
    private val socket = SocketManager.getSocket()
    private val scriptLogs = mutableMapOf<String, MutableList<String>>() // Mapa para almacenar logs de todos los scripts

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(buildMainLayout())
        fetchScripts()
        socket.connect()
        // Escuchar eventos: orders y products
        socket.on("scripts_update", onScripts)


        // Escuchar eventos: orders y products
    }
    // Listener para el evento "products"
    private val onScripts = Emitter.Listener { args ->
        // Verificar si el primer argumento es un JSONArray
        val jsonArray = args[0] as? JSONArray
        jsonArray?.let {
            // Convertir el JSONArray en una lista de Strings
            val scriptNames = mutableListOf<String>()
            for (i in 0 until jsonArray.length()) {
                scriptNames.add(jsonArray.getString(i))
            }

            // Luego mapear la lista de nombres a objetos Script
            val scripts = scriptNames.map { name -> Script(name) }

            // Finalmente, llamar a displayScripts para actualizar la UI
            runOnUiThread {
                displayScripts(scripts)
            }
        }
    }


    private fun buildMainLayout(): LinearLayout {
        val mainLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT
            )
        }

        val scrollView = ScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        val scriptsContainer = LinearLayout(this).apply {
            id = R.id.scriptsContainer
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        scrollView.addView(scriptsContainer)
        mainLayout.addView(scrollView)

        return mainLayout
    }

    private fun fetchScripts() {
        RetrofitClient.apiService.getScripts().enqueue(object : Callback<List<String>> {
            override fun onResponse(call: Call<List<String>>, response: Response<List<String>>) {
                if (response.isSuccessful) {
                    val scriptNames = response.body()
                    scriptNames?.let {
                        val scripts = it.map { name -> Script(name) }
                        displayScripts(scripts)
                    }
                } else {
                    Log.e("Error", "Error al obtener los scripts")
                }
            }

            override fun onFailure(call: Call<List<String>>, t: Throwable) {
                Log.e("Error", "Fallo en la llamada: ${t.message}")
            }
        })
    }

    private fun displayScripts(scripts: List<Script>) {
        val scriptsContainer = findViewById<LinearLayout>(R.id.scriptsContainer)
        scriptsContainer.removeAllViews()

        for (script in scripts) {
            val scriptLayout = LinearLayout(this).apply {
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
                orientation = LinearLayout.HORIZONTAL
                setPadding(0, 16, 0, 16)
            }

            val scriptNameTextView = TextView(this).apply {
                text = script.name
                layoutParams = LinearLayout.LayoutParams(
                    0,
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    1f
                )
            }

            val startStopButton = Button(this).apply {
                text = "Iniciar"
                setOnClickListener {
                    val action = if (text == "Iniciar") "start" else "stop"
                    controlScript(script.name, action)
                    text = if (action == "start") "Detener" else "Iniciar"
                }
            }

            val logsButton = Button(this).apply {
                text = "Logs"
                setOnClickListener {
                    fetchScriptLogs(script.name) // Ahora se usa esta función cuando se presiona el botón de "Logs"
                }
            }

            // Obtener el estado del script y cambiar el texto del botón
            getScriptStatus(script.name) { status ->
                if (status == "running") {
                    startStopButton.text = "Detener"
                } else {
                    startStopButton.text = "Iniciar"
                }
            }

            scriptLayout.addView(scriptNameTextView)
            scriptLayout.addView(startStopButton)
            scriptLayout.addView(logsButton)

            scriptsContainer.addView(scriptLayout)
        }
    }

    private fun controlScript(scriptName: String, action: String) {
        RetrofitClient.apiService.controlScript(scriptName, action).enqueue(object : Callback<Map<String, String>> {
            override fun onResponse(call: Call<Map<String, String>>, response: Response<Map<String, String>>) {
                if (response.isSuccessful) {
                    val message = response.body()?.get("message") ?: "Acción realizada"
                    Toast.makeText(this@MainActivity, "$message en $scriptName", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this@MainActivity, "Error en $action de $scriptName", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onFailure(call: Call<Map<String, String>>, t: Throwable) {
                Toast.makeText(this@MainActivity, "Error de red: ${t.message}", Toast.LENGTH_SHORT).show()
            }
        })
    }

    private fun getScriptStatus(scriptName: String, callback: (String) -> Unit) {
        RetrofitClient.apiService.getScriptStatus(scriptName).enqueue(object : Callback<ScriptStatus> {
            override fun onResponse(call: Call<ScriptStatus>, response: Response<ScriptStatus>) {
                if (response.isSuccessful) {
                    val scriptStatus = response.body()
                    val status = scriptStatus?.status ?: "stopped"
                    callback(status)
                } else {
                    Toast.makeText(this@MainActivity, "Error al obtener estado de $scriptName", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onFailure(call: Call<ScriptStatus>, t: Throwable) {
                Toast.makeText(this@MainActivity, "Error de red: ${t.message}", Toast.LENGTH_SHORT).show()
            }
        })
    }

    private fun fetchScriptLogs(scriptName: String) {
        RetrofitClient.apiService.getScriptStatus(scriptName).enqueue(object : Callback<ScriptStatus> {
            override fun onResponse(call: Call<ScriptStatus>, response: Response<ScriptStatus>) {
                if (response.isSuccessful) {
                    val scriptStatus = response.body()
                    val logs = scriptStatus?.stdoutLogs?.joinToString("\n") ?: "Sin logs"
                    val errorLogs = scriptStatus?.stderrLogs?.joinToString("\n") ?: "Sin logs de error"

                    // Almacenar los logs de esta ejecución
                    scriptLogs.getOrPut(scriptName) { mutableListOf() }.apply {
                        add("=== Logs de ejecución ===\n$logs")
                        add("=== Logs de error ===\n$errorLogs")
                    }

                    // Mostrar los logs completos en un AlertDialog
                    val logsText = """
                        === Logs de salida ===
                        $logs
                        
                        === Logs de error ===
                        $errorLogs
                    """.trimIndent()

                    val builder = AlertDialog.Builder(this@MainActivity)
                    builder.setTitle("Logs de $scriptName")
                    builder.setMessage(logsText) // Mostrar los logs completos de esta ejecución
                    builder.setPositiveButton("Cerrar") { dialog, _ ->
                        dialog.dismiss()
                    }
                    builder.show()
                } else {
                    Toast.makeText(this@MainActivity, "Error al obtener logs de $scriptName", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onFailure(call: Call<ScriptStatus>, t: Throwable) {
                Toast.makeText(this@MainActivity, "Error de red: ${t.message}", Toast.LENGTH_SHORT).show()
            }
        })
    }
    override fun onDestroy() {
        super.onDestroy()
        socket.disconnect() // Desconectar el socket cuando la actividad se destruye
    }
}
