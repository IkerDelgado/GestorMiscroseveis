package com.example.missockets.network

data class Script(
    val name: String
)
