console.log('Mongo en ejecución...');
setTimeout(() => {
    console.log('Mongo ha terminado.');
}, 5000);