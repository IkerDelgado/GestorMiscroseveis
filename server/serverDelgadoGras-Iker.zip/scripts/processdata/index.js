console.log('Data en ejecución...');
setTimeout(() => {
    console.log('Data ha terminado.');
}, 10000);