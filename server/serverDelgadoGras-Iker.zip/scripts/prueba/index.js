console.log('Prueba en ejecución...');
idInterval = setInterval(() => {
    console.log('Prueba ha terminado.');
}, 2000);

// Lo haces de forma controlada
//clearInterval(idInterval)